int add() {
    int result;
    result = a + b;
}
