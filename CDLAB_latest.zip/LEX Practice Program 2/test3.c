#include<stdio.h>
#include<stdlib.h>

int main() {
    printf("Hello world!");
    scanf("%d");
    printf("Done");
    return 0;
}
