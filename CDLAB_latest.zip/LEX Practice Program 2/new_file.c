#include<stdio.h>
#include<stdlib.h>

int main() {
    writef("Hello world!");
    readf("%d");
    writef("Done");
    return 0;
}
