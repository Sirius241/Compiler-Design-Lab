int main() {
    int a = 10, b = 20;
    float sum;
    sum = a + b;
    if (sum > 10) {
        return 1;
    }
    return 0;
}
