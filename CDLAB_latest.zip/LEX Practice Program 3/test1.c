#include <stdio.h>

// This is a single-line comment

int main() {
    printf("Hello\n"); /* Inline multi-line comment
                         on multiple lines */
    return 0;
}
