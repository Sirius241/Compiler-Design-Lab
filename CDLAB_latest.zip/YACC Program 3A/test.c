for (i = 0; i < 3; i++) {
    b = 5;
    for (j = 0; j < 2; j++) {
        for (;;) {
            a = a + 2;
        }
    }
}
